package Project;

public class Project1 {

	public static void main(String[] args) {
		byte a=10;
		short b= a;   //implicit type casting
		System.out.println("a = "+a);
		System.out.println("b = "+b);
		short c=20;
		byte d =(byte)c;   //explicit type casting
		System.out.println("c = "+c);
		System.out.println("d = "+d);
	}
}
